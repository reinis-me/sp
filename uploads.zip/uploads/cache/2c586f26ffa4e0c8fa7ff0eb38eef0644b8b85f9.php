<?php $__env->startSection('content'); ?>
  
    
    
  

  <header>
      <div class="container">
          <div class="page-title">Sans profession</div>
          <div class="menu-container"></div>
      </div>
  </header>
  <section class="top-banner-holder">
      <div class="container"></div>
  </section>
  <section class="first-articles">
      <div class="container">
          <div class="row">
              <div class="col-12 col-lg-8">
                  <div class="content-block">
                      <h2>New</h2>

                  </div>
              </div>
              <div class="col-12 col-lg-4">
                  <div class="content-block">
                  <h2>This week's love</h2>
                  </div>
                  <div class="content-block">
                  <h2>Reader's highlight</h2>
                  </div>
              </div>
          </div>
      </div>
  </section>
  <section class="spotlight-holder">
      <div class="container">
          <div class="row">
              <div class="col-12 col-lg-8">
                  <div class="content-block">
                      <h2>Everything else</h2>

                  </div>
              </div>
          </div>
      </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>