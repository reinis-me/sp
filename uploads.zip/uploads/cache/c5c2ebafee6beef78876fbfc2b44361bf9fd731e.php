<footer class="page-footer">
  <div class="container">SANS PROFESSION &copy; <?php echo date("Y"); ?></div>
</footer>